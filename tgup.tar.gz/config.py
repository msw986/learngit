import os
from dotenv import load_dotenv
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 加载环境变量
load_dotenv()

# 文件路径映射配置 - 定义文件名和对应的上传目录
FILE_PATH_MAPPING = {
    'a_new.json': '/', #dev
    'd11_new.json': '/', #prod
    'live188Config_cn2_new.json': '/app/sdkassets/',
    'live188Config_cn2_core.json': '/app/sdkassets/',
    'initConfig_cn2_new.json': '/app/sdkassets/',
    'initConfig_cn2_core.json': '/app/sdkassets/',
    'live188Config_new.json': '/app/sdkassets/',
    'live188Config_core.json': '/app/sdkassets/',
    'initConfig_new.json': '/app/sdkassets/',
    'initConfig_core.json': '/app/sdkassets/',
    # 可以添加更多映射
}

def get_dynamic_buckets(prefix, max_buckets=10):
    """动态获取桶配置"""
    buckets = {}
    for i in range(1, max_buckets + 1):
        bucket_key = f'{prefix}_BUCKET_{i}'
        region_key = f'{prefix}_BUCKET_{i}_REGION'
        endpoint_key = f'{prefix}_BUCKET_{i}_ENDPOINT'
        
        bucket = os.getenv(bucket_key)
        if bucket:
            buckets[f'bucket_{i}'] = bucket
            if os.getenv(region_key):
                buckets[f'bucket_{i}_region'] = os.getenv(region_key)
            if os.getenv(endpoint_key):
                buckets[f'bucket_{i}_endpoint'] = os.getenv(endpoint_key)
    return buckets

def get_dynamic_repos(prefix, max_repos=10):
    """动态获取仓库配置"""
    repos = {}
    for i in range(1, max_repos + 1):
        repo_key = f'{prefix}_REPO_{i}'
        repo = os.getenv(repo_key)
        if repo:
            repos[f'repo_{i}'] = repo
    return repos

def get_dynamic_accounts(prefix, max_accounts=10):
    """动态获取账号配置"""
    accounts = {}
    for i in range(1, max_accounts + 1):
        access_token = os.getenv(f'{prefix}_ACCOUNT_{i}_ACCESS_TOKEN')
        owner = os.getenv(f'{prefix}_ACCOUNT_{i}_OWNER')
        
        if access_token and owner:
            accounts[f'account_{i}'] = {
                'access_token': access_token,
                'owner': owner,
                **get_dynamic_repos(f'{prefix}_ACCOUNT_{i}')
            }
    return accounts

# 调试：打印所有环境变量
logger.info("=== 环境变量检查 ===")
logger.info(f"TELEGRAM_BOT_TOKEN: {os.getenv('TELEGRAM_BOT_TOKEN')}")
logger.info(f"ALLOWED_GROUP_ID: {os.getenv('ALLOWED_GROUP_ID')}")

# AWS S3 配置检查
logger.info("\n=== AWS S3 配置检查 ===")
logger.info(f"S3_ACCOUNT_1_ACCESS_KEY_ID: {os.getenv('S3_ACCOUNT_1_ACCESS_KEY_ID')}")
logger.info(f"S3_ACCOUNT_1_SECRET_ACCESS_KEY: {os.getenv('S3_ACCOUNT_1_SECRET_ACCESS_KEY')}")

# 腾讯云 COS 配置检查
logger.info("\n=== 腾讯云 COS 配置检查 ===")
logger.info(f"COS_ACCOUNT_1_SECRET_ID: {os.getenv('COS_ACCOUNT_1_SECRET_ID')}")
logger.info(f"COS_ACCOUNT_1_SECRET_KEY: {os.getenv('COS_ACCOUNT_1_SECRET_KEY')}")

# 阿里云 OSS 配置检查
logger.info("\n=== 阿里云 OSS 配置检查 ===")
logger.info(f"OSS_ACCOUNT_1_ACCESS_KEY_ID: {os.getenv('OSS_ACCOUNT_1_ACCESS_KEY_ID')}")
logger.info(f"OSS_ACCOUNT_1_ACCESS_KEY_SECRET: {os.getenv('OSS_ACCOUNT_1_ACCESS_KEY_SECRET')}")

# Gitee 配置检查
logger.info("\n=== Gitee 配置检查 ===")
for i in range(1, 11):  # 检查最多10个账号
    access_token = os.getenv(f'GITEE_ACCOUNT_{i}_ACCESS_TOKEN')
    owner = os.getenv(f'GITEE_ACCOUNT_{i}_OWNER')
    if access_token and owner:
        logger.info(f"\nGitee 账号 {i} 配置:")
        logger.info(f"GITEE_ACCOUNT_{i}_ACCESS_TOKEN: {access_token}")
        logger.info(f"GITEE_ACCOUNT_{i}_OWNER: {owner}")
        # 检查仓库配置
        for j in range(1, 11):  # 检查最多10个仓库
            repo = os.getenv(f'GITEE_ACCOUNT_{i}_REPO_{j}')
            if repo:
                logger.info(f"GITEE_ACCOUNT_{i}_REPO_{j}: {repo}")

# AWS S3 配置 - 支持多个账号，每个账号多个bucket
S3_ACCOUNTS = {
    'account_1': {
        'access_key_id': os.getenv('S3_ACCOUNT_1_ACCESS_KEY_ID'),
        'secret_access_key': os.getenv('S3_ACCOUNT_1_SECRET_ACCESS_KEY'),
        **get_dynamic_buckets('S3_ACCOUNT_1')
    }
}

# 腾讯云 COS 配置 - 支持多个账号，每个账号多个bucket
COS_ACCOUNTS = {
    'account_1': {
        'secret_id': os.getenv('COS_ACCOUNT_1_SECRET_ID'),
        'secret_key': os.getenv('COS_ACCOUNT_1_SECRET_KEY'),
        **get_dynamic_buckets('COS_ACCOUNT_1')
    }
}

# 阿里云 OSS 配置 - 支持多个账号，每个账号多个bucket
OSS_ACCOUNTS = {
    'account_1': {
        'access_key_id': os.getenv('OSS_ACCOUNT_1_ACCESS_KEY_ID'),
        'access_key_secret': os.getenv('OSS_ACCOUNT_1_ACCESS_KEY_SECRET'),
        **get_dynamic_buckets('OSS_ACCOUNT_1')
    }
}

# Gitee 配置 - 支持多个账号，每个账号多个仓库
GITEE_ACCOUNTS = get_dynamic_accounts('GITEE')

# Telegram Bot 配置
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')

# 允许使用的群组ID
ALLOWED_GROUP_ID = int(os.getenv('ALLOWED_GROUP_ID', '-1001234567890'))  # 从环境变量获取群组ID

# 允许的用户列表
ALLOWED_USERS = [
    int(user_id.strip()) for user_id in 
    os.getenv('ALLOWED_USERS', '123456789,987654321').split(',')
    if user_id.strip()
]  # 从环境变量获取用户ID列表，用逗号分隔

# 调试模式
DEBUG_MODE = os.getenv('DEBUG_MODE', 'False').lower() == 'true'  # 从环境变量获取调试模式设置

# 其他配置... 
