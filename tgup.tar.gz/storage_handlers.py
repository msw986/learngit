import boto3
from qcloud_cos import CosConfig, CosS3Client
import oss2
import requests
import os
import json
from config import *
from crypto_utils import CryptoUtils
import logging
import time
import base64
import chardet

logger = logging.getLogger(__name__)

def detect_file_encoding(file_path):
    """检测文件编码
    
    Args:
        file_path: 文件路径
        
    Returns:
        str: 检测到的编码
    """
    try:
        # 读取文件的前 1024 字节来检测编码
        with open(file_path, 'rb') as f:
            raw_data = f.read(1024)
            result = chardet.detect(raw_data)
            encoding = result['encoding']
            
            # 如果检测不到编码，默认使用 utf-8
            if not encoding:
                encoding = 'utf-8'
                
            return encoding
    except Exception as e:
        logger.error(f"检测文件编码失败: {str(e)}")
        return 'utf-8'  # 出错时默认使用 utf-8

class StorageHandler:
    def __init__(self):
        self.s3_clients = self._init_s3_accounts()
        self.cos_clients = self._init_cos_accounts()
        self.oss_clients = self._init_oss_accounts()
        self.gitee_accounts = self._init_gitee_accounts()
        self.crypto = CryptoUtils()
        self.temp_dir = "temp"
        os.makedirs(self.temp_dir, exist_ok=True)
        self.encrypted_file = None
        self.encrypted_content = None

    def _retry_operation(self, operation, max_retries=3, delay=1):
        """重试机制
        
        Args:
            operation: 要执行的操作函数
            max_retries: 最大重试次数
            delay: 初始延迟时间（秒）
            
        Returns:
            操作的结果
            
        Raises:
            Exception: 如果所有重试都失败
        """
        last_error = None
        for attempt in range(max_retries):
            try:
                return operation()
            except Exception as e:
                last_error = e
                if attempt == max_retries - 1:  # 最后一次尝试
                    break
                logger.warning(f"操作失败，{delay}秒后重试 ({attempt + 1}/{max_retries}): {str(e)}")
                time.sleep(delay)
                delay *= 2  # 指数退避
        
        raise last_error

    def _validate_json(self, file_path):
        """验证文件是否为有效的JSON格式"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                json.loads(content)
            return True, None
        except json.JSONDecodeError as e:
            return False, f"JSON格式错误: {str(e)}"
        except Exception as e:
            return False, f"文件读取错误: {str(e)}"

    def _init_s3_accounts(self):
        clients = {}
        for account_name, account_info in S3_ACCOUNTS.items():
            if (not account_info['access_key_id'] or 
                not account_info['secret_access_key'] or 
                'your_' in account_info['access_key_id'] or 
                'your_' in account_info['secret_access_key']):
                logger.warning(f"S3 账号 {account_name} 缺少必要的配置或使用默认值，已跳过")
                continue
                
            logger.info(f"初始化 S3 账号 {account_name}")
            
            # 获取所有配置的桶
            buckets = []
            bucket_index = 1
            while True:
                bucket_key = f'bucket_{bucket_index}'
                region_key = f'bucket_{bucket_index}_region'
                
                if bucket_key not in account_info or region_key not in account_info:
                    break
                    
                bucket_name = account_info[bucket_key]
                bucket_region = account_info[region_key]
                
                if bucket_name and bucket_region:
                    buckets.append({
                        'name': bucket_name,
                        'region': bucket_region,
                        'client': boto3.client(
                            's3',
                            aws_access_key_id=account_info['access_key_id'],
                            aws_secret_access_key=account_info['secret_access_key'],
                            region_name=bucket_region
                        )
                    })
                    logger.info(f"添加桶: {bucket_name}, 区域: {bucket_region}")
                
                bucket_index += 1
            
            if not buckets:
                logger.warning(f"S3 账号 {account_name} 没有配置任何桶，已跳过")
                continue
            
            clients[account_name] = {
                'buckets': buckets
            }
        return clients

    def _init_cos_accounts(self):
        clients = {}
        for account_name, account_info in COS_ACCOUNTS.items():
            if (not account_info['secret_id'] or 
                not account_info['secret_key'] or 
                'your_' in account_info['secret_id'] or 
                'your_' in account_info['secret_key']):
                logger.warning(f"COS 账号 {account_name} 缺少必要的配置或使用默认值，已跳过")
                continue
                
            logger.info(f"初始化 COS 账号 {account_name}")
            
            # 获取所有配置的桶
            buckets = []
            bucket_index = 1
            while True:
                bucket_key = f'bucket_{bucket_index}'
                region_key = f'bucket_{bucket_index}_region'
                
                if bucket_key not in account_info or region_key not in account_info:
                    break
                    
                bucket_name = account_info[bucket_key]
                bucket_region = account_info[region_key]
                
                if bucket_name and bucket_region:
                    buckets.append({
                        'name': bucket_name,
                        'region': bucket_region,
                        'client': CosS3Client(CosConfig(
                            Region=bucket_region,
                            SecretId=account_info['secret_id'],
                            SecretKey=account_info['secret_key']
                        ))
                    })
                    logger.info(f"添加桶: {bucket_name}, 区域: {bucket_region}")
                
                bucket_index += 1
            
            if not buckets:
                logger.warning(f"COS 账号 {account_name} 没有配置任何桶，已跳过")
                continue
            
            clients[account_name] = {
                'buckets': buckets
            }
        return clients

    def _init_oss_accounts(self):
        clients = {}
        for account_name, account_info in OSS_ACCOUNTS.items():
            if (not account_info['access_key_id'] or 
                not account_info['access_key_secret'] or 
                'your_' in account_info['access_key_id'] or 
                'your_' in account_info['access_key_secret']):
                logger.warning(f"OSS 账号 {account_name} 缺少必要的配置或使用默认值，已跳过")
                continue
                
            logger.info(f"初始化 OSS 账号 {account_name}")
            
            # 获取所有配置的桶
            buckets = []
            bucket_index = 1
            while True:
                bucket_key = f'bucket_{bucket_index}'
                endpoint_key = f'bucket_{bucket_index}_endpoint'
                
                if bucket_key not in account_info or endpoint_key not in account_info:
                    break
                    
                bucket_name = account_info[bucket_key]
                bucket_endpoint = account_info[endpoint_key]
                
                if bucket_name and bucket_endpoint:
                    # 自动处理 endpoint
                    if not bucket_endpoint.startswith('http'):
                        # 根据桶名判断区域
                        if 'bj' in bucket_name.lower():
                            region = 'cn-beijing'
                        elif 'sh' in bucket_name.lower():
                            region = 'cn-shanghai'
                        elif 'sz' in bucket_name.lower():
                            region = 'cn-shenzhen'
                        else:
                            region = 'cn-beijing'  # 默认使用北京区域
                        
                        bucket_endpoint = f'https://oss-{region}.aliyuncs.com'
                    
                    auth = oss2.Auth(
                        account_info['access_key_id'],
                        account_info['access_key_secret']
                    )
                    buckets.append({
                        'name': bucket_name,
                        'endpoint': bucket_endpoint,
                        'client': oss2.Bucket(auth, bucket_endpoint, bucket_name)
                    })
                    logger.info(f"添加桶: {bucket_name}, 端点: {bucket_endpoint}")
                
                bucket_index += 1
            
            if not buckets:
                logger.warning(f"OSS 账号 {account_name} 没有配置任何桶，已跳过")
                continue
            
            clients[account_name] = {
                'buckets': buckets
            }
        return clients

    def _init_gitee_accounts(self):
        accounts = {}
        for account_name, account_info in GITEE_ACCOUNTS.items():
            if (not account_info['access_token'] or 
                not account_info['owner'] or 
                'your_' in account_info['access_token'] or 
                'your_' in account_info['owner']):
                logger.warning(f"Gitee 账号 {account_name} 缺少必要的配置或使用默认值，已跳过")
                continue
                
            logger.info(f"初始化 Gitee 账号 {account_name}")
            
            # 获取所有配置的仓库
            repos = []
            repo_index = 1
            while True:
                repo_key = f'repo_{repo_index}'
                
                if repo_key not in account_info:
                    break
                    
                repo_name = account_info[repo_key]
                
                if repo_name:
                    repos.append({
                        'name': repo_name,
                        'headers': {
                            'Authorization': f'token {account_info["access_token"]}',
                            'Content-Type': 'application/json'
                        }
                    })
                    logger.info(f"添加仓库: {repo_name}")
                
                repo_index += 1
            
            if not repos:
                logger.warning(f"Gitee 账号 {account_name} 没有配置任何仓库，已跳过")
                continue
            
            accounts[account_name] = {
                'owner': account_info['owner'],
                'repos': repos
            }
        return accounts

    def _get_upload_path(self, file_name):
        """根据文件名获取上传路径"""
        return FILE_PATH_MAPPING.get(file_name, '/')

    def _encrypt_file(self, file_path):
        """加密文件"""
        logger.info(f"开始加密文件: {file_path}")
        encrypted_file = f"{file_path}.encrypted"
        
        # 读取文件内容
        logger.info(f"使用 utf-8 编码读取文件")
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        logger.info(f"文件内容长度: {len(content)} 字节")
        
        # 加密内容
        logger.info("开始加密数据")
        try:
            # 确保内容是有效的 JSON
            json.loads(content)  # 验证 JSON 格式
            
            # 使用 crypto_utils 进行加密
            encrypted_content = self.crypto.encrypt_data(content)
            logger.info(f"加密完成，结果长度: {len(encrypted_content)} 字节")
            
            # 保存加密文件
            logger.info(f"保存加密文件到: {encrypted_file}")
            with open(encrypted_file, 'w', encoding='utf-8') as f:
                f.write(encrypted_content)
                f.flush()  # 确保数据写入磁盘
                os.fsync(f.fileno())  # 确保文件系统同步
            
            return encrypted_file, encrypted_content
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON 格式错误: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"加密失败: {str(e)}")
            raise

    def _download_and_decrypt(self, url, temp_path):
        """下载并解密文件"""
        try:
            logger.info(f"开始下载文件: {url}")
            # 下载文件
            headers = {
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache',
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            response = requests.get(url, headers=headers)
            logger.info(f"下载响应状态码: {response.status_code}")
            
            if response.status_code != 200:
                logger.error(f"下载失败，状态码: {response.status_code}")
                logger.error(f"响应内容: {response.text}")
                return None
            
            # 解密文件
            logger.info("开始解密文件")
            encrypted_content = response.text
            decrypted_content = self.crypto.decrypt_data(encrypted_content)
            
            # 保存解密后的文件
            logger.info(f"保存解密文件到: {temp_path}")
            with open(temp_path, 'w', encoding='utf-8') as f:
                f.write(decrypted_content)
                f.flush()
                os.fsync(f.fileno())
            
            return temp_path
        except Exception as e:
            logger.error(f"下载或解密文件失败: {str(e)}", exc_info=True)
            return None

    def _compare_files(self, file1_path, file2_path):
        """比较两个文件的内容"""
        try:
            # 读取并解析第一个文件
            logger.info(f"读取第一个文件: {file1_path}")
            with open(file1_path, 'r', encoding='utf-8') as f1:
                try:
                    content1 = json.load(f1)
                    logger.info(f"成功解析第一个文件")
                except json.JSONDecodeError as e:
                    logger.error(f"解析文件 {file1_path} 失败: {str(e)}")
                    return [f"解析文件 {file1_path} 失败: {str(e)}"]
            
            # 读取并解析第二个文件
            logger.info(f"读取第二个文件: {file2_path}")
            with open(file2_path, 'r', encoding='utf-8') as f2:
                try:
                    content2 = json.load(f2)
                    logger.info(f"成功解析第二个文件")
                except json.JSONDecodeError as e:
                    logger.error(f"解析文件 {file2_path} 失败: {str(e)}")
                    return [f"解析文件 {file2_path} 失败: {str(e)}"]
            
            # 比较两个JSON对象
            logger.info("开始比较文件内容")
            differences = []
            self._compare_json_objects(content1, content2, differences)
            
            if differences:
                logger.info(f"发现 {len(differences)} 处差异")
            else:
                logger.info("文件内容完全相同")
                
            return differences
        except Exception as e:
            logger.error(f"比较文件时发生错误: {str(e)}", exc_info=True)
            return [f"比较文件时发生错误: {str(e)}"]

    def _compare_json_objects(self, obj1, obj2, differences, path=""):
        """递归比较两个JSON对象"""
        if isinstance(obj1, dict) and isinstance(obj2, dict):
            # 检查所有键
            all_keys = set(obj1.keys()) | set(obj2.keys())
            for key in all_keys:
                new_path = f"{path}.{key}" if path else key
                if key not in obj1:
                    differences.append(f"新增: {new_path} = {obj2[key]}")
                elif key not in obj2:
                    differences.append(f"删除: {new_path} = {obj1[key]}")
                else:
                    self._compare_json_objects(obj1[key], obj2[key], differences, new_path)
        elif isinstance(obj1, list) and isinstance(obj2, list):
            if len(obj1) != len(obj2):
                differences.append(f"{path}: 数组长度不同 ({len(obj1)} vs {len(obj2)})")
            else:
                for i in range(len(obj1)):
                    self._compare_json_objects(obj1[i], obj2[i], differences, f"{path}[{i}]")
        elif obj1 != obj2:
            differences.append(f"修改: {path}\n  当前值: {obj2}\n  新值: {obj1}")

    def upload_to_s3(self, file_path, target_path=None):
        """上传到 S3"""
        results = {'成功': [], '失败': []}
        encrypted_file, encrypted_content = self._encrypt_file(file_path)
        
        # 获取文件名并移除 temp_ 前缀
        file_name = os.path.basename(file_path).replace('temp_', '')
        # 获取映射路径
        upload_path = self._get_upload_path(file_name)
        if not upload_path:
            logger.error(f"文件 {file_name} 没有配置路径映射")
            return results
            
        logger.info(f"文件 {file_name} 的映射路径: {upload_path}")
        # 构建完整的目标路径
        target_path = target_path or os.path.join(upload_path.lstrip('/'), file_name)
        logger.info(f"完整目标路径: {target_path}")
        
        for account_name, account_info in self.s3_clients.items():
            for bucket_info in account_info['buckets']:
                bucket_name = bucket_info['name']
                client = bucket_info['client']
                
                try:
                    # 确保内容是文本
                    if isinstance(encrypted_content, bytes):
                        content = encrypted_content.decode('utf-8')
                    else:
                        content = encrypted_content
                    
                    def upload_operation():
                        # 检查文件是否存在
                        try:
                            client.head_object(Bucket=bucket_name, Key=target_path)
                            logger.info(f"文件已存在，准备更新")
                        except client.exceptions.ClientError as e:
                            if e.response['Error']['Code'] == '404':
                                logger.info(f"文件不存在，准备创建新文件")
                            else:
                                raise
                            
                        client.put_object(
                            Bucket=bucket_name,
                            Key=target_path,
                            Body=content,
                            ContentType='text/plain'
                        )
                        return True
                    
                    # 使用重试机制
                    self._retry_operation(upload_operation)
                    results['成功'].append(f"{account_name}/{bucket_name}")
                    
                except Exception as e:
                    logger.error(f"S3上传失败 (账户: {account_name}, 桶: {bucket_name}): {str(e)}")
                    results['失败'].append(f"{account_name}/{bucket_name}")
        
        return results

    def upload_to_cos(self, file_path, target_path=None):
        """上传到 COS"""
        results = {'成功': [], '失败': []}
        encrypted_file, encrypted_content = self._encrypt_file(file_path)
        
        # 获取文件名并移除 temp_ 前缀
        file_name = os.path.basename(file_path).replace('temp_', '')
        # 获取映射路径
        upload_path = self._get_upload_path(file_name)
        if not upload_path:
            logger.error(f"文件 {file_name} 没有配置路径映射")
            return results
            
        logger.info(f"文件 {file_name} 的映射路径: {upload_path}")
        # 构建完整的目标路径
        target_path = target_path or os.path.join(upload_path.lstrip('/'), file_name)
        logger.info(f"完整目标路径: {target_path}")
        
        for account_name, account_info in self.cos_clients.items():
            for bucket_info in account_info['buckets']:
                bucket_name = bucket_info['name']
                client = bucket_info['client']
                
                try:
                    # 确保内容是文本
                    if isinstance(encrypted_content, bytes):
                        content = encrypted_content.decode('utf-8')
                    else:
                        content = encrypted_content
                    
                    def upload_operation():
                        # 检查文件是否存在
                        try:
                            client.head_object(Bucket=bucket_name, Key=target_path)
                            logger.info(f"文件已存在，准备更新")
                        except Exception as e:
                            if 'NoSuchResource' in str(e):
                                logger.info(f"文件不存在，准备创建新文件")
                            else:
                                raise
                            
                        client.put_object(
                            Bucket=bucket_name,
                            Body=content,
                            Key=target_path,
                            ContentType='text/plain'
                        )
                        return True
                    
                    # 使用重试机制
                    self._retry_operation(upload_operation)
                    results['成功'].append(f"{account_name}/{bucket_name}")
                    
                except Exception as e:
                    logger.error(f"COS上传失败 (账户: {account_name}, 桶: {bucket_name}): {str(e)}")
                    results['失败'].append(f"{account_name}/{bucket_name}")
        
        return results

    def upload_to_oss(self, file_path):
        """上传文件到 OSS"""
        logger.info("开始上传到 OSS")
        results = {'成功': [], '失败': []}
        
        # 获取文件名并移除 temp_ 前缀
        file_name = os.path.basename(file_path).replace('temp_', '')
        # 获取映射路径
        upload_path = self._get_upload_path(file_name)
        # 构建完整的目标路径
        target_path = os.path.join(upload_path.lstrip('/'), file_name)
        
        # 加密文件
        encrypted_file, encrypted_content = self._encrypt_file(file_path)
        if not encrypted_file:
            logger.error("文件加密失败")
            return results
        
        try:
            # 上传到每个 OSS 账号
            for account_name, account_info in self.oss_clients.items():
                logger.info(f"处理 OSS 账号: {account_name}")
                for bucket_info in account_info['buckets']:
                    bucket_name = bucket_info['name']
                    logger.info(f"处理 OSS 桶: {bucket_name}")
                    
                    # 添加重试机制
                    max_retries = 3
                    retry_delay = 2
                    for attempt in range(max_retries):
                        try:
                            # 检查文件是否存在
                            try:
                                bucket_info['client'].get_object_meta(target_path)
                                logger.info("文件已存在，准备更新")
                            except oss2.exceptions.NoSuchKey:
                                logger.info("文件不存在，准备上传")
                            
                            # 上传文件
                            bucket_info['client'].put_object(target_path, encrypted_content)
                            logger.info(f"OSS 上传成功 (账户: {account_name}, 桶: {bucket_name})")
                            results['成功'].append(f"{account_name}/{bucket_name}")
                            break  # 上传成功，跳出重试循环
                            
                        except Exception as e:
                            if attempt == max_retries - 1:  # 最后一次尝试
                                logger.error(f"OSS上传失败 (账户: {account_name}, 桶: {bucket_name}): {str(e)}")
                                results['失败'].append(f"{account_name}/{bucket_name}")
                            else:
                                logger.warning(f"OSS上传失败，{retry_delay}秒后重试 ({attempt + 1}/{max_retries}) (账户: {account_name}, 桶: {bucket_name}): {str(e)}")
                                time.sleep(retry_delay)
            
        except Exception as e:
            logger.error(f"OSS 上传过程发生错误: {str(e)}")
        finally:
            # 清理临时加密文件
            if os.path.exists(encrypted_file):
                os.remove(encrypted_file)
        
        return results

    def upload_to_gitee(self, file_path, target_path=None):
        """上传到 Gitee"""
        results = {'成功': [], '失败': []}
        print("文件更新中，请耐心等待...")
        encrypted_file, encrypted_content = self._encrypt_file(file_path)
        
        # 获取文件名并移除 temp_ 前缀
        file_name = os.path.basename(file_path).replace('temp_', '')
        # 获取映射路径
        upload_path = self._get_upload_path(file_name)
        if not upload_path:
            logger.error(f"文件 {file_name} 没有配置路径映射")
            return results
            
        logger.info(f"文件 {file_name} 的映射路径: {upload_path}")
        # 构建完整的目标路径
        target_path = target_path or os.path.join(upload_path.lstrip('/'), file_name)
        logger.info(f"完整目标路径: {target_path}")
        
        for account_name, account_info in self.gitee_accounts.items():
            owner = account_info['owner']
            for repo_info in account_info['repos']:
                repo_name = repo_info['name']
                headers = repo_info['headers']
                
                try:
                    # 确保内容是文本
                    if isinstance(encrypted_content, bytes):
                        content = encrypted_content.decode('utf-8')
                    else:
                        content = encrypted_content
                    
                    def upload_operation():
                        # 先检查文件是否存在
                        check_url = f'https://gitee.com/api/v5/repos/{owner}/{repo_name}/contents/{target_path}?ref=master'
                        logger.info(f"检查文件是否存在: {check_url}")
                        check_response = requests.get(check_url, headers=headers, timeout=5)
                        
                        # 构建基础请求数据
                        data = {
                            'content': base64.b64encode(content.encode('utf-8')).decode('utf-8'),
                            'message': f'更新 {repo_name} 仓库中的 {target_path}',
                            'branch': 'master'
                        }
                        
                        # 根据文件是否存在处理
                        if check_response.status_code == 200:
                            try:
                                file_info = check_response.json()
                                if isinstance(file_info, dict) and 'sha' in file_info:
                                    data['sha'] = file_info['sha']
                                    logger.info(f"文件已存在，SHA: {file_info['sha']}")
                                else:
                                    logger.info("文件不存在，准备创建新文件")
                                    data['message'] = f'创建 {repo_name} 仓库中的 {target_path}'
                            except Exception as e:
                                logger.info("文件不存在，准备创建新文件")
                                data['message'] = f'创建 {repo_name} 仓库中的 {target_path}'
                        else:
                            logger.info("文件不存在，准备创建新文件")
                            data['message'] = f'创建 {repo_name} 仓库中的 {target_path}'
                        
                        # 发送请求
                        url = f'https://gitee.com/api/v5/repos/{owner}/{repo_name}/contents/{target_path}'
                        logger.info(f"Gitee API URL: {url}")
                        logger.info(f"Gitee 请求数据: {json.dumps(data, ensure_ascii=False)}")
                        
                        response = requests.put(url, headers=headers, data=json.dumps(data), timeout=5)
                        
                        # 检查响应状态
                        if response.status_code != 200 and response.status_code != 201:
                            raise Exception(f"Gitee API 响应错误: {response.text}")
                        
                        return True
                    
                    # 使用重试机制
                    self._retry_operation(upload_operation)
                    results['成功'].append(f"{account_name}/{repo_name}")
                    
                    # 添加请求间隔
                    logger.info(f"等待 1 秒后继续下一个请求...")
                    time.sleep(1)
                    
                except requests.exceptions.Timeout:
                    logger.error(f"Gitee上传超时 (账户: {account_name}, 仓库: {repo_name})")
                    results['失败'].append(f"{account_name}/{repo_name}")
                except Exception as e:
                    logger.error(f"Gitee上传失败 (账户: {account_name}, 仓库: {repo_name}): {str(e)}")
                    results['失败'].append(f"{account_name}/{repo_name}")
        
        return results

    def compare_with_storage(self, file_path):
        """比较本地文件与存储中的文件"""
        file_name = os.path.basename(file_path)
        # 移除文件名中的 temp_ 前缀
        original_file_name = file_name.replace('temp_', '')
        upload_path = self._get_upload_path(original_file_name)
        logger.info(f"文件 {original_file_name} 的映射路径: {upload_path}")
        
        results = []
        
        # 首先验证本地文件
        try:
            # 检查文件是否存在
            if not os.path.exists(file_path):
                logger.error(f"本地文件不存在: {file_path}")
                return "❌ 本地文件不存在"
            
            # 检查文件大小
            file_size = os.path.getsize(file_path)
            if file_size == 0:
                logger.error(f"本地文件为空: {file_path}")
                return "❌ 本地文件为空"
            
            # 读取并验证本地文件内容
            logger.info(f"读取本地文件: {file_path}")
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                if not content.strip():
                    logger.error(f"本地文件内容为空: {file_path}")
                    return "❌ 本地文件内容为空"
                try:
                    local_content = json.loads(content)
                    logger.info("本地文件解析成功")
                except json.JSONDecodeError as e:
                    logger.error(f"本地文件 JSON 解析失败: {str(e)}")
                    logger.error(f"文件内容: {content[:200]}...")  # 只记录前200个字符
                    return f"❌ 本地文件 JSON 格式错误: {str(e)}"
        except Exception as e:
            logger.error(f"处理本地文件失败: {str(e)}", exc_info=True)
            return f"❌ 处理本地文件失败: {str(e)}"
        
        # 只比较第一个 S3 仓库
        for account_name, account_info in self.s3_clients.items():
            if not account_info['buckets']:
                continue
                
            bucket = account_info['buckets'][0]  # 只取第一个桶
            try:
                # 构建完整的对象路径，使用原始文件名（不带 temp_ 前缀）
                object_path = os.path.join(upload_path.lstrip('/'), original_file_name)
                logger.info(f"S3 对象路径: {object_path}")
                
                # 临时文件路径仅用于本地存储
                temp_path = f"{account_name}_{bucket['name']}_{file_name}"
                
                try:
                    # 尝试获取对象
                    response = bucket['client'].get_object(
                        Bucket=bucket['name'],
                        Key=object_path
                    )
                    content = response['Body'].read().decode('utf-8')
                    
                    # 验证远程文件内容
                    if not content.strip():
                        logger.error("远程文件内容为空")
                        results.append("❌ 远程文件内容为空")
                        continue
                    
                    # 解密内容
                    try:
                        decrypted_content = self.crypto.decrypt_data(content)
                    except Exception as e:
                        logger.error(f"解密远程文件失败: {str(e)}")
                        results.append(f"❌ 解密远程文件失败: {str(e)}")
                        continue
                    
                    # 保存解密后的内容到临时文件
                    with open(temp_path, 'w', encoding='utf-8') as f:
                        f.write(decrypted_content)
                    
                    # 读取并解析远程文件
                    logger.info(f"读取远程文件: {temp_path}")
                    try:
                        with open(temp_path, 'r', encoding='utf-8') as f:
                            remote_content = json.load(f)
                        logger.info("远程文件解析成功")
                    except json.JSONDecodeError as e:
                        logger.error(f"远程文件 JSON 解析失败: {str(e)}")
                        logger.error(f"文件内容: {decrypted_content[:200]}...")  # 只记录前200个字符
                        results.append(f"❌ 远程文件 JSON 格式错误: {str(e)}")
                        continue
                    
                    # 比较文件内容
                    logger.info("开始比较文件内容")
                    differences = []
                    self._compare_json_objects(local_content, remote_content, differences)
                    
                    if differences:
                        logger.info(f"发现 {len(differences)} 处差异")
                        # 使用代码块格式输出差异
                        diff_text = "```\n" + "\n".join(differences) + "\n```"
                        results.append(f"文件差异对比:\n{diff_text}")
                    else:
                        logger.info("文件内容完全相同")
                        results.append(f"✅ 文件内容相同")
                    
                    # 清理临时文件
                    os.remove(temp_path)
                except bucket['client'].exceptions.ClientError as e:
                    if e.response['Error']['Code'] == 'NoSuchKey':
                        logger.info("文件不存在")
                        results.append(f"❌ 库存文件不存在")
                    else:
                        logger.error(f"处理文件失败: {str(e)}", exc_info=True)
                        results.append(f"❌ 处理文件失败: {str(e)}")
                except Exception as e:
                    logger.error(f"处理文件失败: {str(e)}", exc_info=True)
                    results.append(f"❌ 处理文件失败: {str(e)}")
                
                break  # 只处理第一个账号的第一个桶
            except Exception as e:
                logger.error(f"比较失败: {str(e)}", exc_info=True)
                results.append(f"❌ 比较失败: {str(e)}")
                break  # 出错也退出循环
        
        return "\n\n".join(results)

    def _get_all_file_mappings(self):
        """获取所有文件映射
        
        Returns:
            dict: 文件名到路径的映射字典
        """
        return FILE_PATH_MAPPING.copy()

    def save_file(self, file_path, content):
        """保存文件内容"""
        try:
            logger.info(f"保存文件: {file_path}")
            # 确保目录存在
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            # 保存文件
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
                f.flush()  # 确保数据写入磁盘
                os.fsync(f.fileno())  # 确保文件系统同步
            
            logger.info(f"文件保存成功: {file_path}")
            return True
        except Exception as e:
            logger.error(f"保存文件失败: {str(e)}", exc_info=True)
            return False

    def upload_file(self, file_path, remote_path):
        """上传文件到存储服务"""
        try:
            print("文件更新中，请耐心等待...")
            
            # 加密文件
            logger.info(f"开始加密文件: {file_path}")
            encrypted_path, encrypted_data = self.crypto.encrypt_file(file_path)
            if not encrypted_path or not encrypted_data:
                raise Exception("文件加密失败")
            logger.info(f"文件加密成功: {encrypted_path}")

            # 上传加密后的文件
            if self.storage_type == 'aws':
                self.s3.upload_file(encrypted_path, AWS_BUCKET, remote_path)
            elif self.storage_type == 'tencent':
                self.cos.upload_file(
                    Bucket=TENCENT_BUCKET,
                    LocalFilePath=encrypted_path,
                    Key=remote_path
                )
            elif self.storage_type == 'aliyun':
                self.bucket.put_object_from_file(remote_path, encrypted_path)
            elif self.storage_type == 'gitee':
                # 获取文件内容
                with open(encrypted_path, 'r', encoding='ascii') as f:
                    content = f.read()
                
                # 构建 API URL
                api_url = f"https://gitee.com/api/v5/repos/{self.gitee_owner}/{self.gitee_repo}/contents/{remote_path}"
                
                # 准备请求数据
                data = {
                    "access_token": self.gitee_token,
                    "content": content,
                    "message": f"Upload {remote_path}",
                    "branch": self.gitee_branch
                }
                
                # 发送请求
                response = requests.put(api_url, json=data)
                if response.status_code not in [200, 201]:
                    raise Exception(f"上传到 Gitee 失败: {response.text}")

            # 清理临时文件
            try:
                os.remove(encrypted_path)
            except Exception as e:
                logger.warning(f"清理临时文件失败: {str(e)}")

            return True
        except Exception as e:
            logger.error(f"上传文件失败: {str(e)}", exc_info=True)
            return False 
