import os
import logging
import json
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, MessageHandler, CallbackQueryHandler, Filters, ConversationHandler
from storage_handlers import StorageHandler
from config import *
import asyncio
import re
import time
from datetime import datetime
import traceback
import tempfile
import requests

# 配置日志
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# 定义会话状态
WAITING_CONFIRMATION = 1

class TelegramBot:
    def __init__(self):
        self.storage_handler = StorageHandler()
        self.pending_uploads = {}  # 存储待确认的上传信息
        self.failed_uploads = {}   # 存储上传失败的信息
        self.temp_files = {}       # 存储临时文件信息
        self.updater = Updater(TELEGRAM_BOT_TOKEN, use_context=True)
        
        # 设置处理器
        dp = self.updater.dispatcher
        
        # 添加命令处理器
        dp.add_handler(CommandHandler("start", self.start))
        dp.add_handler(CommandHandler("help", self.help))
        dp.add_handler(CommandHandler("get", self.get_file))
        dp.add_handler(CommandHandler("list", self.list_files))
        dp.add_handler(CommandHandler("cancel", self.cancel))
        dp.add_handler(CommandHandler("retry", self.retry_failed))
        dp.add_handler(CommandHandler("cat", self.cat_file))  # 添加 cat 命令处理器
        
        # 添加文件处理器
        dp.add_handler(MessageHandler(
            Filters.document,  # 只检查是否为文档类型
            self.handle_document
        ))
        
        # 添加确认处理器
        dp.add_handler(MessageHandler(
            Filters.text & ~Filters.command,  # 处理文本消息，但不包括命令
            self.handle_confirmation
        ))
        
        # 添加确认按钮处理器
        dp.add_handler(CallbackQueryHandler(self.handle_confirmation, pattern='^confirm_'))

    def check_permission(self, update):
        """检查用户权限"""
        user_id = update.effective_user.id
        username = update.effective_user.username
        chat_id = update.effective_chat.id
        chat_type = update.effective_chat.type
        chat_title = update.effective_chat.title if hasattr(update.effective_chat, 'title') else '私聊'
        
        if DEBUG_MODE:
            logger.info(f"用户尝试使用机器人:")
            logger.info(f"  - 用户ID: {user_id}")
            logger.info(f"  - 用户名: {username}")
            logger.info(f"  - 群组ID: {chat_id}")
            logger.info(f"  - 聊天类型: {chat_type}")
            logger.info(f"  - 群组名称: {chat_title}")
        
        # 检查是否在允许的群组中
        if update.effective_chat.id != ALLOWED_GROUP_ID:
            update.message.reply_text("抱歉，此机器人只能在指定的群组中使用。")
            return False
            
        # 检查用户是否在允许列表中
        if user_id not in ALLOWED_USERS:
            update.message.reply_text("抱歉，您没有权限使用此机器人。")
            return False
            
        return True

    def start(self, update, context):
        """处理 /start 命令"""
        if not self.check_permission(update):
            return
            
        update.message.reply_text(
            "欢迎使用文件上传机器人！\n"
            "请发送 JSON 文件，我会自动比较并上传到所有配置的存储服务。"
        )

    def help(self, update, context):
        """处理 /help 命令"""
        if not self.check_permission(update):
            return
            
        update.message.reply_text(
            "使用说明：\n"
            "1. 发送 JSON 文件，我会自动比较并上传\n"
            "2. 使用 /get 文件名 命令下载文件\n"
            "3. 使用 /list 命令查看支持的文件列表\n"
            "4. 使用 /cancel 命令取消当前操作"
        )

    def get_file(self, update, context):
        """处理 /get 命令"""
        logger.info("收到 /get 命令")
        if not self.check_permission(update):
            logger.warning("权限检查失败")
            return

        # 检查是否提供了文件名
        if not context.args:
            logger.warning("未提供文件名")
            update.message.reply_text("请提供文件名，例如：/get a_new.json")
            return
        
        file_name = context.args[0]
        logger.info(f"请求下载文件: {file_name}")
        
        # 创建临时目录
        with tempfile.TemporaryDirectory() as temp_dir:
            logger.info(f"创建临时目录: {temp_dir}")
            try:
                # 从第一个 S3 仓库下载文件
                for account_name, account_info in self.storage_handler.s3_clients.items():
                    logger.info(f"检查 S3 账号: {account_name}")
                    logger.info(f"账号信息: {account_info}")
                    if account_info['buckets']:  # 确保有桶
                        bucket_info = account_info['buckets'][0]  # 只取第一个桶
                        bucket_name = bucket_info['name']  # 获取桶名称
                        logger.info(f"桶信息: {bucket_info}")
                        try:
                            # 获取文件映射路径
                            upload_path = self.storage_handler._get_upload_path(file_name)
                            logger.info(f"文件映射路径: {upload_path}")
                            
                            # 构建完整的对象路径
                            object_path = os.path.join(upload_path.lstrip('/'), file_name)
                            logger.info(f"完整对象路径: {object_path}")
                            
                            # 下载加密文件
                            encrypted_path = os.path.join(temp_dir, f"encrypted_{file_name}")
                            
                            # 下载文件
                            logger.info("开始下载文件")
                            try:
                                response = bucket_info['client'].get_object(
                                    Bucket=bucket_name,
                                    Key=object_path
                                )
                                content = response['Body'].read().decode('utf-8')
                                
                                # 保存加密文件
                                logger.info(f"保存加密文件到: {encrypted_path}")
                                with open(encrypted_path, 'w', encoding='utf-8') as f:
                                    f.write(content)
                                
                                # 解密文件
                                logger.info("开始解密文件")
                                decrypted_path = self.storage_handler.crypto.decrypt_file(encrypted_path)
                                if not decrypted_path:
                                    logger.error("文件解密失败")
                                    update.message.reply_text("文件解密失败")
                                    return
                                logger.info(f"解密完成，文件保存在: {decrypted_path}")
                                
                                # 发送解密后的文件
                                logger.info("开始发送解密后的文件")
                                with open(decrypted_path, 'rb') as f:
                                    update.message.reply_document(
                                        document=f,
                                        filename=f"{file_name}"
                                    )
                                logger.info("文件发送完成")
                                return
                                
                            except bucket_info['client'].exceptions.ClientError as e:
                                if e.response['Error']['Code'] == 'NoSuchKey':
                                    logger.error("文件不存在")
                                    update.message.reply_text("文件不存在")
                                else:
                                    logger.error(f"下载文件失败: {str(e)}")
                                    update.message.reply_text("下载文件失败")
                                return
                            
                        except Exception as e:
                            logger.error(f"处理文件失败: {str(e)}", exc_info=True)
                            update.message.reply_text("下载或解密失败")
                            return
                
                logger.warning("没有找到可用的 S3 桶")
                update.message.reply_text("没有找到可用的 S3 桶")
                
            except Exception as e:
                logger.error(f"处理文件失败: {str(e)}", exc_info=True)
                update.message.reply_text("处理文件失败")

    def handle_document(self, update, context):
        """处理接收到的文件"""
        logger.info("收到文件消息")
        logger.info(f"消息详情: {update.message}")
        
        if not self.check_permission(update):
            logger.warning("权限检查失败")
            return

        # 获取文件信息
        file = update.message.document
        file_name = file.file_name
        logger.info(f"文件名: {file_name}")
        logger.info(f"文件大小: {file.file_size} 字节")
        logger.info(f"MIME类型: {file.mime_type}")

        # 检查文件类型
        if not file_name.endswith('.json'):
            logger.warning(f"不支持的文件类型: {file_name}")
            update.message.reply_text("只支持 JSON 文件上传。")
            return

        # 下载文件
        file_path = f"temp_{file_name}"
        logger.info(f"开始下载文件到: {file_path}")
        try:
            file.get_file().download(file_path)
            logger.info("文件下载完成")
            
            # 验证文件是否为有效的 JSON 格式
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    if not content.strip():
                        logger.error("文件内容为空")
                        update.message.reply_text("❌ 文件内容为空")
                        if os.path.exists(file_path):
                            os.remove(file_path)
                        return
                    
                    try:
                        json.loads(content)
                        logger.info("文件是有效的 JSON 格式")
                    except json.JSONDecodeError as e:
                        logger.error(f"文件不是有效的 JSON 格式: {str(e)}")
                        update.message.reply_text(f"❌ 文件不是有效的 JSON 格式: {str(e)}")
                        if os.path.exists(file_path):
                            os.remove(file_path)
                        return
            except Exception as e:
                logger.error(f"验证文件格式失败: {str(e)}")
                update.message.reply_text(f"❌ 验证文件格式失败: {str(e)}")
                if os.path.exists(file_path):
                    os.remove(file_path)
                return

            # 进行文件比对
            logger.info("开始文件比对")
            comparison_results = self.storage_handler.compare_with_storage(file_path)
            logger.info("文件比对完成")
            
            # 存储待确认的上传信息
            self.pending_uploads[update.effective_user.id] = {
                'file_path': file_path,
                'file_name': file_name
            }
            logger.info(f"已存储待确认信息，用户ID: {update.effective_user.id}")

            # 发送比对结果和确认提示
            logger.info("发送比对结果和确认提示")
            update.message.reply_text(
                f"文件比对结果：\n\n{comparison_results}\n\n"
                "请回复 'yes' 确认上传，或回复其他内容取消上传。"
            )
            
            return WAITING_CONFIRMATION

        except Exception as e:
            logger.error(f"处理文件时发生错误: {str(e)}", exc_info=True)
            update.message.reply_text(f"处理文件时发生错误: {str(e)}")
            if os.path.exists(file_path):
                logger.info(f"清理临时文件: {file_path}")
                os.remove(file_path)
            return ConversationHandler.END

    def handle_confirmation(self, update, context):
        """处理用户确认"""
        logger.info("收到确认消息")
        logger.info(f"消息内容: {update.message.text}")
        
        if not self.check_permission(update):
            logger.warning("权限检查失败")
            return ConversationHandler.END

        user_id = update.effective_user.id
        logger.info(f"用户ID: {user_id}")
        
        if user_id not in self.pending_uploads:
            logger.warning("没有找到待确认的上传任务")
            update.message.reply_text("没有待确认的上传任务。")
            return ConversationHandler.END

        pending_upload = self.pending_uploads[user_id]
        file_path = pending_upload['file_path']
        file_name = pending_upload['file_name']
        logger.info(f"待确认文件: {file_name}")

        if update.message.text.lower() == 'yes':
            logger.info("用户确认上传")
            try:
                # 发送提醒消息
                status_message = update.message.reply_text("文件更新中，请耐心等待...")
                
                # 上传到各个存储服务，带重试机制
                def upload_with_retry(upload_func, max_retries=3, delay=2):
                    for attempt in range(max_retries):
                        try:
                            return upload_func()
                        except Exception as e:
                            if attempt == max_retries - 1:  # 最后一次尝试
                                logger.error(f"上传失败，已达到最大重试次数: {str(e)}")
                                raise
                            logger.warning(f"上传失败，{delay}秒后重试 ({attempt + 1}/{max_retries}): {str(e)}")
                            time.sleep(delay)
                
                # 上传到 S3
                logger.info("开始上传到 S3")
                s3_results = upload_with_retry(lambda: self.storage_handler.upload_to_s3(file_path))
                logger.info("S3 上传完成")
                
                # 上传到 COS
                logger.info("开始上传到 COS")
                cos_results = upload_with_retry(lambda: self.storage_handler.upload_to_cos(file_path))
                logger.info("COS 上传完成")
                
                # 上传到 OSS
                logger.info("开始上传到 OSS")
                oss_results = upload_with_retry(lambda: self.storage_handler.upload_to_oss(file_path))
                logger.info("OSS 上传完成")
                
                # 上传到 Gitee
                logger.info("开始上传到 Gitee")
                gitee_results = upload_with_retry(lambda: self.storage_handler.upload_to_gitee(file_path))
                logger.info("Gitee 上传完成")
                
                # 构建结果消息
                result_message = "文件上传结果：\n\n"
                
                # 获取文件名并移除 temp_ 前缀
                file_name = os.path.basename(file_path).replace('temp_', '')
                # 获取映射路径
                upload_path = self.storage_handler._get_upload_path(file_name)
                # 构建完整的目标路径
                target_path = os.path.join(upload_path.lstrip('/'), file_name)
                
                # 显示完整的文件路径
                result_message += f"文件路径: /{target_path}\n\n"
                
                # 记录失败的服务
                failed_services = []
                
                # S3 结果
                s3_success = len(s3_results['成功'])
                s3_failed = len(s3_results['失败'])
                result_message += f"S3: {s3_success}个成功, {s3_failed}个失败\n"
                for bucket in s3_results['成功']:
                    result_message += f"  🟢 {bucket}/{target_path}\n"
                for bucket in s3_results['失败']:
                    result_message += f"  🔴 {bucket}/{target_path}\n"
                if s3_failed > 0:
                    failed_services.append('S3')
                result_message += "\n"
                
                # COS 结果
                cos_success = len(cos_results['成功'])
                cos_failed = len(cos_results['失败'])
                result_message += f"COS: {cos_success}个成功, {cos_failed}个失败\n"
                for bucket in cos_results['成功']:
                    result_message += f"  🟢 {bucket}/{target_path}\n"
                for bucket in cos_results['失败']:
                    result_message += f"  🔴 {bucket}/{target_path}\n"
                if cos_failed > 0:
                    failed_services.append('COS')
                result_message += "\n"
                
                # OSS 结果
                oss_success = len(oss_results['成功'])
                oss_failed = len(oss_results['失败'])
                result_message += f"OSS: {oss_success}个成功, {oss_failed}个失败\n"
                for bucket in oss_results['成功']:
                    result_message += f"  🟢 {bucket}/{target_path}\n"
                for bucket in oss_results['失败']:
                    result_message += f"  🔴 {bucket}/{target_path}\n"
                if oss_failed > 0:
                    failed_services.append('OSS')
                result_message += "\n"
                
                # Gitee 结果
                gitee_success = len(gitee_results['成功'])
                gitee_failed = len(gitee_results['失败'])
                result_message += f"Gitee: {gitee_success}个成功, {gitee_failed}个失败\n"
                for repo in gitee_results['成功']:
                    result_message += f"  🟢 {repo}/{target_path}\n"
                for repo in gitee_results['失败']:
                    result_message += f"  🔴 {repo}/{target_path}\n"
                if gitee_failed > 0:
                    failed_services.append('Gitee')
                
                # 如果有失败的服务，保存失败信息
                if failed_services:
                    self.failed_uploads[user_id] = {
                        'file_path': file_path,
                        'file_name': file_name,
                        'failed_services': failed_services
                    }
                    result_message += "\n有部分上传失败，可以使用 /retry 命令重试失败的上传。"
                else:
                    # 如果所有上传都成功，清理临时文件
                    if os.path.exists(file_path):
                        logger.info(f"清理临时文件: {file_path}")
                        os.remove(file_path)
                
                # 发送上传结果
                logger.info("发送上传结果")
                update.message.reply_text(result_message)
            except Exception as e:
                logger.error(f"上传文件时发生错误: {str(e)}", exc_info=True)
                update.message.reply_text(f"上传文件时发生错误: {str(e)}")
        else:
            logger.info("用户取消上传")
            update.message.reply_text("已取消上传。")
            # 取消上传时也清理临时文件
            if os.path.exists(file_path):
                logger.info(f"清理临时文件: {file_path}")
                os.remove(file_path)

        # 清理待确认信息
        logger.info("清理待确认信息")
        del self.pending_uploads[user_id]

        return ConversationHandler.END

    def cancel(self, update, context):
        """取消当前操作"""
        if not self.check_permission(update):
            return ConversationHandler.END

        user_id = update.effective_user.id
        if user_id in self.pending_uploads:
            file_path = self.pending_uploads[user_id]['file_path']
            if os.path.exists(file_path):
                os.remove(file_path)
            del self.pending_uploads[user_id]

        update.message.reply_text("操作已取消。")
        return ConversationHandler.END

    def list_files(self, update, context):
        """处理 /list 命令，显示支持的文件列表"""
        logger.info("收到 /list 命令")
        if not self.check_permission(update):
            logger.warning("权限检查失败")
            return
        
        try:
            # 获取所有文件映射
            file_mappings = self.storage_handler._get_all_file_mappings()
            
            if not file_mappings:
                update.message.reply_text("当前没有配置任何文件映射。")
                return
            
            # 构建消息
            message = "支持的文件列表：\n\n"
            for file_name, path in file_mappings.items():
                message += f"📄 {file_name}\n"
                message += f"   └─ 路径: {path}\n\n"
            
            update.message.reply_text(message)
            
        except Exception as e:
            logger.error(f"获取文件列表失败: {str(e)}", exc_info=True)
            update.message.reply_text("获取文件列表失败")

    def retry_failed(self, update, context):
        """重试失败的上传"""
        logger.info("收到重试命令")
        if not self.check_permission(update):
            logger.warning("权限检查失败")
            return

        user_id = update.effective_user.id
        if user_id not in self.failed_uploads:
            update.message.reply_text("没有需要重试的上传任务。")
            return

        failed_info = self.failed_uploads[user_id]
        file_path = failed_info['file_path']
        file_name = failed_info['file_name']
        failed_services = failed_info['failed_services']
        
        logger.info(f"开始重试上传文件: {file_name}")
        logger.info(f"失败的服务: {failed_services}")
        
        try:
            # 发送提醒消息
            status_message = update.message.reply_text("正在重试上传失败的文件...")
            
            # 重试上传到各个失败的服务
            results = {}
            for service in failed_services:
                if service == 'S3':
                    results['S3'] = self.storage_handler.upload_to_s3(file_path)
                elif service == 'COS':
                    results['COS'] = self.storage_handler.upload_to_cos(file_path)
                elif service == 'OSS':
                    results['OSS'] = self.storage_handler.upload_to_oss(file_path)
                elif service == 'Gitee':
                    results['Gitee'] = self.storage_handler.upload_to_gitee(file_path)
            
            # 构建结果消息
            result_message = "重试上传结果：\n\n"
            
            # 获取文件名并移除 temp_ 前缀
            file_name = os.path.basename(file_path).replace('temp_', '')
            # 获取映射路径
            upload_path = self.storage_handler._get_upload_path(file_name)
            # 构建完整的目标路径
            target_path = os.path.join(upload_path.lstrip('/'), file_name)
            
            # 显示完整的文件路径
            result_message += f"文件路径: /{target_path}\n\n"
            
            # 显示每个服务的结果
            for service, result in results.items():
                success = len(result['成功'])
                failed = len(result['失败'])
                result_message += f"{service}: {success}个成功, {failed}个失败\n"
                for bucket in result['成功']:
                    result_message += f"  🟢 {bucket}/{target_path}\n"
                for bucket in result['失败']:
                    result_message += f"  🔴 {bucket}/{target_path}\n"
                result_message += "\n"
            
            # 发送重试结果
            update.message.reply_text(result_message)
            
            # 更新失败记录
            all_success = all(len(result['失败']) == 0 for result in results.values())
            if all_success:
                # 如果所有重试都成功，清理临时文件和失败记录
                if os.path.exists(file_path):
                    logger.info(f"清理临时文件: {file_path}")
                    os.remove(file_path)
                del self.failed_uploads[user_id]
            else:
                # 更新失败的服务列表
                new_failed_services = []
                for service, result in results.items():
                    if len(result['失败']) > 0:
                        new_failed_services.append(service)
                self.failed_uploads[user_id]['failed_services'] = new_failed_services
            
        except Exception as e:
            logger.error(f"重试上传失败: {str(e)}", exc_info=True)
            update.message.reply_text(f"重试上传失败: {str(e)}")

    def cat_file(self, update, context):
        """处理 /cat 命令，显示文件的明文内容"""
        logger.info("收到 /cat 命令")
        if not self.check_permission(update):
            logger.warning("权限检查失败")
            return

        # 检查是否提供了文件名
        if not context.args:
            logger.warning("未提供文件名")
            update.message.reply_text("请提供文件名，例如：/cat a_new.json")
            return
        
        file_name = context.args[0]
        logger.info(f"请求查看文件内容: {file_name}")
        
        # 创建临时目录
        with tempfile.TemporaryDirectory() as temp_dir:
            logger.info(f"创建临时目录: {temp_dir}")
            try:
                # 从第一个 S3 仓库下载文件
                for account_name, account_info in self.storage_handler.s3_clients.items():
                    logger.info(f"检查 S3 账号: {account_name}")
                    if account_info['buckets']:  # 确保有桶
                        bucket_info = account_info['buckets'][0]  # 只取第一个桶
                        bucket_name = bucket_info['name']  # 获取桶名称
                        try:
                            # 获取文件映射路径
                            upload_path = self.storage_handler._get_upload_path(file_name)
                            logger.info(f"文件映射路径: {upload_path}")
                            
                            # 构建完整的对象路径
                            object_path = os.path.join(upload_path.lstrip('/'), file_name)
                            logger.info(f"完整对象路径: {object_path}")
                            
                            # 下载加密文件
                            encrypted_path = os.path.join(temp_dir, f"encrypted_{file_name}")
                            
                            # 下载文件
                            logger.info("开始下载文件")
                            try:
                                response = bucket_info['client'].get_object(
                                    Bucket=bucket_name,
                                    Key=object_path
                                )
                                content = response['Body'].read().decode('utf-8')
                                
                                # 保存加密文件
                                logger.info(f"保存加密文件到: {encrypted_path}")
                                with open(encrypted_path, 'w', encoding='utf-8') as f:
                                    f.write(content)
                                
                                # 解密文件
                                logger.info("开始解密文件")
                                decrypted_path = self.storage_handler.crypto.decrypt_file(encrypted_path)
                                if not decrypted_path:
                                    logger.error("文件解密失败")
                                    update.message.reply_text("文件解密失败")
                                    return
                                logger.info(f"解密完成，文件保存在: {decrypted_path}")
                                
                                # 读取并发送解密后的内容
                                logger.info("开始读取解密后的内容")
                                with open(decrypted_path, 'r', encoding='utf-8') as f:
                                    content = f.read()
                                
                                # 如果内容太长，分段发送
                                if len(content) > 4000:
                                    chunks = [content[i:i+4000] for i in range(0, len(content), 4000)]
                                    for i, chunk in enumerate(chunks):
                                        update.message.reply_text(f"内容片段 {i+1}/{len(chunks)}:\n{chunk}")
                                else:
                                    update.message.reply_text(f"文件内容:\n{content}")
                                
                                return
                                
                            except bucket_info['client'].exceptions.ClientError as e:
                                if e.response['Error']['Code'] == 'NoSuchKey':
                                    logger.error("文件不存在")
                                    update.message.reply_text("文件不存在")
                                else:
                                    logger.error(f"下载文件失败: {str(e)}")
                                    update.message.reply_text("下载文件失败")
                                return
                            
                        except Exception as e:
                            logger.error(f"处理文件失败: {str(e)}", exc_info=True)
                            update.message.reply_text("下载或解密失败")
                            return
                
                logger.warning("没有找到可用的 S3 桶")
                update.message.reply_text("没有找到可用的 S3 桶")
                
            except Exception as e:
                logger.error(f"处理文件失败: {str(e)}", exc_info=True)
                update.message.reply_text("处理文件失败")

def main():
    """启动机器人"""
    bot = TelegramBot()
    updater = bot.updater
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main() 
