from Crypto.Cipher import AES
import base64
import logging
import os

logger = logging.getLogger(__name__)

class CryptoUtils:
    def __init__(self):
        # 确保密钥是16字节（128位）
        key = 'Manbetx2019-2021'
        self.key = key.encode('utf-8')[:16].ljust(16, b'\0')  # 截取或补齐到16字节

    def encrypt_data(self, data):
        """对数据进行AES加密"""
        try:
            # 确保输入是字符串
            if isinstance(data, bytes):
                data = data.decode('utf-8')
                
            # 计算需要填充的字节数
            data_bytes = data.encode('utf-8')
            pad_len = 16 - (len(data_bytes) % 16)
            padded_data = data_bytes + (b'\0' * pad_len)
            
            # 加密
            cipher = AES.new(self.key, AES.MODE_ECB)
            encrypted_data = cipher.encrypt(padded_data)
            
            # Base64 编码并返回字符串
            return base64.b64encode(encrypted_data).decode('ascii')
        except Exception as e:
            logger.error(f"加密失败: {str(e)}", exc_info=True)
            return None

    def decrypt_data(self, encrypted_base64):
        """解密 Base64 编码的 AES 密文"""
        try:
            # 确保输入是字符串
            if isinstance(encrypted_base64, bytes):
                encrypted_base64 = encrypted_base64.decode('utf-8')
            
            # Base64 解码
            encrypted_data = base64.b64decode(encrypted_base64)
            
            # 解密
            cipher = AES.new(self.key, AES.MODE_ECB)
            decrypted_data = cipher.decrypt(encrypted_data).rstrip(b'\0')
            
            # 返回字符串
            return decrypted_data.decode('utf-8')
        except Exception as e:
            logger.error(f"解密失败: {str(e)}", exc_info=True)
            return None

    def encrypt_file(self, file_path):
        """加密文件"""
        try:
            logger.info(f"开始加密文件: {file_path}")
            
            # 读取文件内容
            logger.info("读取文件内容")
            with open(file_path, 'r', encoding='utf-8') as f:
                data = f.read()
            logger.info(f"文件内容长度: {len(data)} 字节")
            
            # 加密数据
            logger.info("开始加密数据")
            encrypted_data = self.encrypt_data(data)
            if not encrypted_data:
                logger.error("加密失败")
                raise Exception("加密失败")
            logger.info("数据加密完成")
            
            # 保存加密文件
            encrypted_path = f"{file_path}.encrypted"
            logger.info(f"保存加密文件到: {encrypted_path}")
            with open(encrypted_path, 'w', encoding='ascii') as f:
                f.write(encrypted_data)
                f.flush()  # 确保数据写入磁盘
                os.fsync(f.fileno())  # 确保文件系统同步
            
            return encrypted_path, encrypted_data
        except Exception as e:
            logger.error(f"加密文件失败: {str(e)}", exc_info=True)
            raise

    def decrypt_file(self, file_path):
        """解密文件"""
        try:
            logger.info(f"开始解密文件: {file_path}")
            
            # 读取加密文件
            logger.info("读取加密文件")
            with open(file_path, 'r', encoding='ascii') as f:
                encrypted_data = f.read()
            logger.info(f"加密文件内容长度: {len(encrypted_data)} 字节")
            
            # 解密数据
            logger.info("开始解密数据")
            decrypted_data = self.decrypt_data(encrypted_data)
            if not decrypted_data:
                logger.error("解密失败")
                raise Exception("解密失败")
            logger.info("数据解密完成")
            
            # 保存解密文件
            decrypted_path = f"{file_path}.decrypted"
            logger.info(f"保存解密文件到: {decrypted_path}")
            with open(decrypted_path, 'w', encoding='utf-8') as f:
                f.write(decrypted_data)
                f.flush()  # 确保数据写入磁盘
                os.fsync(f.fileno())  # 确保文件系统同步
            
            return decrypted_path
        except Exception as e:
            logger.error(f"解密文件失败: {str(e)}", exc_info=True)
            raise 
