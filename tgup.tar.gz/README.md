# Telegram 文件上传机器人

这是一个 Telegram 机器人，可以帮助用户将文件上传到多个云存储平台，包括：
- AWS S3
- 腾讯云 COS
- 阿里云 OSS
- Gitee

## 功能特点

- 支持多个云存储平台
- 简单易用的命令系统
- 支持批量上传到所有平台
- 自动清理临时文件
- 详细的上传状态反馈

## 安装步骤

1. 克隆项目到本地：
```bash
git clone <repository-url>
cd <project-directory>
```

2. 安装依赖：
```bash
pip install -r requirements.txt
```

3. 配置环境变量：
创建 `.env` 文件并添加以下配置：
```env
# Telegram Bot 配置
TELEGRAM_BOT_TOKEN=your_bot_token

# AWS S3 配置
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
AWS_REGION=your_aws_region
S3_BUCKET=your_bucket_name

# 腾讯云 COS 配置
COS_SECRET_ID=your_cos_secret_id
COS_SECRET_KEY=your_cos_secret_key
COS_REGION=your_cos_region
COS_BUCKET=your_cos_bucket

# 阿里云 OSS 配置
OSS_ACCESS_KEY_ID=your_oss_access_key
OSS_ACCESS_KEY_SECRET=your_oss_secret
OSS_ENDPOINT=your_oss_endpoint
OSS_BUCKET=your_oss_bucket

# Gitee 配置
GITEE_ACCESS_TOKEN=your_gitee_token
GITEE_OWNER=your_gitee_username
GITEE_REPO=your_repo_name
```

## 使用方法

1. 启动机器人：
```bash
python bot.py
```

2. 在 Telegram 中与机器人交互：
   - 发送 `/start` 获取使用说明
   - 使用以下命令选择上传目标：
     - `/s3` - 上传到 AWS S3
     - `/cos` - 上传到腾讯云 COS
     - `/oss` - 上传到阿里云 OSS
     - `/gitee` - 上传到 Gitee
     - `/all` - 上传到所有平台
   - 发送文件给机器人

## 注意事项

1. 确保所有云存储服务的配置信息正确
2. 文件上传后会自动清理临时文件
3. 上传大文件时可能需要等待较长时间
4. 建议使用私有仓库进行 Gitee 上传

## 错误处理

如果遇到上传失败，机器人会返回详细的错误信息。常见错误包括：
- 配置信息错误
- 网络连接问题
- 权限不足
- 存储空间不足

## 贡献

欢迎提交 Issue 和 Pull Request 来帮助改进这个项目。 